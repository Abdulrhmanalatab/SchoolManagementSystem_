<?php
include_once('main.php');
?>
<html>
    <head>
		    <link rel="stylesheet" type="text/css" href="../../source/CSS/style.css">
				<script src = "JS/login_logout.js"></script>
		</head>
    <body>
    <div class="header"><h1>School Management System</h1>
    <h4 class="hi">Hi!admin <?php echo $get_name;?></h4></div>
			  <div class="divtopcorner">
				    <img src="../../source/logo.jpg" height="150" width="150" alt="School Management System"/>
				</div>
			<br/><br/>
				<ul align="center">
				    <li class="manulist">
						    <a class ="menulista" href="index.php">Home</a>
								<a class ="menulista" href="addPayment.php">Add Payment</a>
								<a class ="menulista" href="deletePayment.php">Delete Payment</a>
								<div align="center">
								
								    <a class ="menulistaa" href="http://localhost/a/index.php" onmouseover="changemouseover(this);" onmouseout="changemouseout(this,'<?php echo ucfirst($loged_user_name);?>');"><?php echo "Logout";?></a>
						    </div>
						</li>
				</ul>
			  <hr/>
        <center>
            <h1>Student Tuition Fees</h1>
            <form action="#" method="post">
                <table cellpadding="6">
                  <tr>
                      <td>Student ID:</td>
                      <td><input type="text" name="id" placeholder="Enter Student Id."></td>
                  </tr>
                  <tr>
                      <td>Ammount:</td>
                      <td><input type="text" name="ammount" placeholder="Enter Ammount."></td>
                  </tr>
                  <tr>
                      <td>Month:</td>
                      <td><input type="text" name="month" placeholder="Enter Month.(April as 4)"></td>
                  </tr>
                  <tr>
                      <td>Year:</td>
                      <td><input type="text" name="year" placeholder="Enter Year.(2016)"></td>
                  </tr>
                  <tr>
                      <td></td>
                      <td><input type="submit" name="submit" value="Submit"></td>
                  </tr>
                </table>
            </form>
        </center>
		</body>
</html>
<?php
include_once('../../service/mysqlcon.php');
if(!empty($_POST['submit'])){
    $id = $_POST['id'];
    $ammount = $_POST['ammount'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $sql = "INSERT INTO payment VALUES('','$id','$ammount','$month','$year')";
    $success = mysqli_query( $link,$sql );
    if(!$success) {
        die('Could not enter data: '.mysqli_error($link));
    }
    echo "Transaction successfull\n";
}
?>
