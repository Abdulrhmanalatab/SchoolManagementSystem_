<?php
include_once('main.php');
include_once('../../service/mysqlcon.php');
$string = "<tr>
    <th>Click To Dlete</th>
    <th>ID</th>
    <th>Student Id</th>
    <th>Amount</th>
    <th>Month</th>
    <th>Year</th>
    </tr>";
$sql = "SELECT * FROM payment WHERE month = MONTH(curdate()) AND year = YEAR(curdate())";
$res = mysqli_query($link,$sql);
while($row = mysqli_fetch_array($res)){
    $string .= "<form action='deletePaymentableData.php' method='post'>".
    " <table><tr><td><input id='deletes' type='submit' name='submit' value='Delete'></td>".
    "</td><td>".$row['id']."</td><td>".$row['studentid']."</td><td>".$row['amount'].
    "</td><td>".$row['month']."</td><td>".$row['year']."</td></tr></table></form>";
}
?>
<html>
    <head>
		    <link rel="stylesheet" type="text/css" href="../../source/CSS/style.css">
				<script src = "JS/login_logout.js"></script>
        <script src = "JS/searchPayment.js"></script>
		

		</head>
    <body>
	<div class="header"><h1>School Management System</h1>
    <h4 class="hi">Hi!admin <?php echo $get_name;?></h4></div>
			  <div class="divtopcorner">
				    <img src="../../source/logo.jpg" height="150" width="150" alt="School Management System"/>
				</div>
			<br/><br/>
				<ul align="center">
				    <li class="manulist">
						    <a class ="menulista" href="index.php">Home</a>
								<a class ="menulista" href="addPayment.php">Add Payment</a>
								<a class ="menulista" href="deletePayment.php">Delete Payment</a>
								<div align="center">
								
								    <a class ="menulistaa" href="http://localhost/a/index.php" onmouseover="changemouseover(this);" onmouseout="changemouseout(this,'<?php echo ucfirst($loged_user_name);?>');"><?php echo "Logout";?></a>
						    </div>
						</li>
				</ul>
			  <hr/>
        <center>
            <h1>Delete Payment</h1>
            <table>
                <tr>
                    <td><b>Search By Payment Id Or Student Id</b></td>
                    <td><input type="text" onkeyup="getPayment(this.value);"></td>
                </tr>
            </table>
            <div id="paymentList">
            </div>
        </center>
		</body>
</html>
