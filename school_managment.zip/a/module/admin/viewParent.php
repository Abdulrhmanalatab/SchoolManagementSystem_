<?php
include_once('main.php');
include_once('../../service/mysqlcon.php');
$sql = "SELECT * FROM parents;";
$res= mysqli_query($link,$sql);
$string = "";
while($row = mysqli_fetch_array($res)){
    $string .= '<tr><td>'.$row['id'].'</td><td>'.$row['password'].
    '</td><td>'.$row['fathername'].'</td><td>'.$row['mothername'].
    '</td><td>'.$row['fatherphone'].'</td><td>'.$row['motherphone'].
    '</td><td>'.$row['address'].'</td></tr>';
}
?>
<html>
    <head>
		    <link rel="stylesheet" type="text/css" href="../../source/CSS/style.css">
				<script src = "JS/login_logout.js"></script>
        <script src = "JS/searchParent.js"></script>
		</head>
    <body>
    <div class="header"><h1>School Management System</h1>
    <h4 class="hi">Hi!admin <?php echo $get_name." ";?></h4></div>
			 
				<ul align="center">
				    <li class="manulist">
						    <a class ="menulista" href="index.php">Home</a>
                <a class ="menulista" href="addParent.php">New Parent</a>
                <a class ="menulista" href="viewParent.php">View Parent</a>
                <a class ="menulista" href="updateParent.php">Update Parent</a>
                <a class ="menulista" href="deleteParent.php">Delete Parent</a>
								<div align="center">
								
								<a class ="menulistaa" href="http://localhost/a/index.php" onmouseover="changemouseover(this);" onmouseout="changemouseout(this,'<?php echo ucfirst($loged_user_name);?>');"><?php echo "Logout";?></a>
						</div>
								</li>
				</ul>
			  <hr/>
        <center>
            <table>
                <tr>
                    <td><b>Search By Id Or Name: </b></td>
                    <td><input type="text" name="searchId" placeholder="Search By Id Or Name:" onkeyup="getParent(this.value);"></td>
                </tr>
            </table>
        </center>
        <br/>
        <center><h2>Parent List</h2></center>
        <center>
            <table border="1" id='parentList'>
                <tr>
                    <th>ID</th>
                    <th>Password</th>
                    <th>Father Name</th>
                    <th>Mother Name</th>
                    <th>Father Phone</th>
                    <th>Mother Phone</th>
                    <th>Address</th>
                </tr>
                <?php echo $string;?>
            </table>
        </center>
		</body>
</html>
