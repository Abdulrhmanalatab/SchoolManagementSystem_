<?php
$login_code= isset($_REQUEST['login']) ? $_REQUEST['login'] : '1';
if($login_code=="false"){
    $login_message="Wrong Credentials !(-/-)";
	  $color="red";
}
else{
    $login_message="Please Login ! (+~+)";
	  $color="green";
}
?>
<!DOCTYPE html>
<html >
    <head>
        <link rel="stylesheet" type="text/css" href="../../source/CSS/style.css">
        <meta charset="UTF-8">
	      <script src="source/js/loginValidate.js"></script>
        <title>School Management System</title>
    </head>
    <body>
        <center>
	          <img src="source/logo.jpg" />
              <div class="login-box">
            <h3>صفحة تسجيل الدخول</h3>
 <form  action="service/check.access.php" onsubmit="return loginValidate();" method="post"><br/>
   <div class="user-box">
     <input type="text" id="myid" name="myid"  autofocus=""/>
     <label>Username</label>
   </div>
   <div class="user-box">
     <input type="password" id="mypassword" name="mypassword" />
     <label>Password</label>
   </div><center>
   <button  type="submit" value="Login">
         login
      <span></span>
   </button></center>
 </form>
</div>
<style>
    body{
    
    background-color: #FFECD6;
    }
.login-box {
  position: absolute;
  top: 65%;
  left: 50%;
  width: 400px;
  padding: 40px;
  transform: translate(-50%, -50%);
  background: rgba(24, 20, 20, 0.987);
  box-sizing: border-box;
  box-shadow: 0 15px 25px rgba(0,0,0,.6);
  border-radius: 10px;
}
.login-box h3{
  color: #fff;
}

.login-box .user-box {
  position: relative;
}

.login-box .user-box input {
  width: 100%;
  padding: 10px 0;
  font-size: 16px;
  color: #fff;
  margin-bottom: 30px;
  border: none;
  border-bottom: 1px solid #fff;
  outline: none;
  background: transparent;
}

.login-box .user-box label {
  position: absolute;
  top: 0;
  left: 0;
  padding: 10px 0;
  font-size: 16px;
  color: #fff;
  pointer-events: none;
  transition: .5s;
}

.login-box .user-box input:focus ~ label,
.login-box .user-box input:valid ~ label {
  top: -20px;
  left: 0;
  color: #B68F8F;
  font-size: 12px;
}

.login-box form button {
  position: relative;
  display: inline-block;
  padding: 10px 20px;
  color: #000000;
  font-size: 16px;
  text-decoration: none;
  text-transform: uppercase;
  overflow: hidden;
  transition: .5s;
  margin-top: 40px;
  letter-spacing: 4px;
  background-color: blanchedalmond;
}

.login-box button:hover {
  background: #FFECD6;
  color:black;
  border-radius: 5px;
  box-shadow: 0 0 5px #FFECD6,
              0 0 25px #FFECD6,
              0 0 50px #FFECD6,
              0 0 100px #FFECD6;
}

.login-box button span {
  position: absolute;
  display: block;
}

@keyframes btn-anim1 {
  0% {
    left: -100%;
  }

  50%,100% {
    left: 100%;
  }
}

.login-box button span:nth-child(1) {
  bottom: 2px;
  left: -100%;
  width: 100%;
  height: 2px;
  background: linear-gradient(90deg, transparent, #EDECF4);
  animation: btn-anim1 2s linear infinite;
}
    </style>
    </body>
</html>
